# NormalMap-Online
NormalMap Generator Online

A free tool to create normal maps.

You may use all normal maps you create here as you see fit. They are yours and will not be saved anywhere. The scripts are running on your machine only.

Please, as I have very limited time on this project, contribute via pull requests if you are able to.

To run the tool in your browser, [use this link](https://cpetry.github.io/NormalMap-Online/).